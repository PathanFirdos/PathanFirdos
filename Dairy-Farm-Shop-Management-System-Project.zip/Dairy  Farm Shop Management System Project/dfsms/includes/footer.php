            <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
<p>Dairy Farm Shop Management System</p>
                        </div>
                    </div>
                </footer>
            </div>